% =========================================================================
% SCRIPT: entrenamiento.m
% Fase 1 y 2: Preprocesado, Fusión, Cross-Validation y Entrenamiento
% =========================================================================
clear all; close all; clc;



% 1. FASE DE PREPROCESADO
disp('-> [Fase 1] Preprocesando y fusionando datos...');
T_final = preprocesar_datos('historico.txt');
disp(['   [OK] Filas de entrenamiento disponibles: ', num2str(height(T_final))]);


% 2. FASE DE ENTRENAMIENTO FINAL (100% de los datos)
disp('-> [Fase 3] Entrenando modelo FINAL (100% datos) para guardar en modelo.mat...');
modelo = entrenar_modelo_simple(T_final);

% Guardar el modelo simple para prediccion.m
coefs_temp = modelo.temp;
coefs_viento = modelo.viento;
coefs_precip = modelo.precip;
save('modelo.mat', 'coefs_temp', 'coefs_viento', 'coefs_precip');

disp('   [OK] Modelo guardado en modelo.mat');







%% 1. PREPROCESADO Y FUSIÓN DE DATOS
function T_final = preprocesar_datos(fichero)
    
% 1.1.Cargamos el histórico
    fid = fopen(fichero, 'r');
    lineas = textscan(fid, '%s', 'Delimiter', '\n');
    fclose(fid);
    lineas = lineas{1};

    datos_real = {}; datos_pred = {};

    for i = 1:length(lineas)
        elementos = strsplit(lineas{i}, ';');
        tipo = elementos{1};

        if strcmp(tipo, 'PRED') % Datos de prediccion
            fuente = elementos{2};
            f_cap = datetime(elementos{3}, 'InputFormat', 'yyyy-MM-dd''T''HH:mm');
            
            f_obj = datetime(elementos{4}, 'InputFormat', 'yyyy-MM-dd''T''HH:mm');
            if strcmp(fuente, 'AEMET'); f_obj = f_obj - hours(2); end   % La aemet da los de prediccion en utc+2
            
            temp = str2double(elementos{5});
            viento = str2double(elementos{6});
            precip = str2double(elementos{7});

            horizonte = round(hours(f_obj - f_cap));

            if horizonte > 0 && horizonte <= 48
                datos_pred(end+1, :) = {fuente, f_obj, horizonte, temp, viento, precip};
            end

        elseif strcmp(tipo, 'REAL') % Datos de observacion
            f_obs = datetime(elementos{3}, 'InputFormat', 'yyyy-MM-dd''T''HH:mm');
            temp = str2double(elementos{4});
            viento = str2double(elementos{5});
            precip = str2double(elementos{6});

            datos_real(end+1, :) = {f_obs, temp, viento, precip};
        end
    end

% 1.2. Limpiamos los datos

    % 1.2.1. Obtenemos los Datos de observacion (la Y)
    T_real = cell2table(datos_real, 'VariableNames', {'FechaObj', 'Temp_REAL', 'Viento_REAL', 'Precip_REAL'});
    [~, idx_unique] = unique(T_real.FechaObj); % Eliminamos fechas repetidas
    T_real = T_real(idx_unique, :);

    % 1.2.1. Obtenemos los Datos de prediccion (patrones)
    T_pred = cell2table(datos_pred, 'VariableNames', {'Fuente', 'FechaObj', 'Horizonte', 'Temp', 'Viento', 'Precip'});

        % 1.2.1.1. Obtenemos los datos aislados de cada fuente (con mismo horizonte y fecha objetivo)
        [grupos, ~, idx_grupos] = unique(T_pred(:, {'FechaObj', 'Horizonte'}), 'rows');
    
        N = height(grupos);
        Temp_AEMET = NaN(N,1); Temp_OM = NaN(N,1); Temp_OWM = NaN(N,1);
        Viento_AEMET = NaN(N,1); Viento_OM = NaN(N,1); Viento_OWM = NaN(N,1);
        Precip_AEMET = NaN(N,1); Precip_OM = NaN(N,1); Precip_OWM = NaN(N,1);
    
        for i = 1:N
            filas_grupo = T_pred(idx_grupos == i, :);
            for j = 1:height(filas_grupo)
                fuente = filas_grupo.Fuente{j};
                if strcmp(fuente, 'AEMET')
                    Temp_AEMET(i) = filas_grupo.Temp(j); Viento_AEMET(i) = filas_grupo.Viento(j); Precip_AEMET(i) = filas_grupo.Precip(j);
                elseif strcmp(fuente, 'OPEN-METEO')
                    Temp_OM(i) = filas_grupo.Temp(j); Viento_OM(i) = filas_grupo.Viento(j); Precip_OM(i) = filas_grupo.Precip(j);
                elseif strcmp(fuente, 'OWM')
                    Temp_OWM(i) = filas_grupo.Temp(j); Viento_OWM(i) = filas_grupo.Viento(j); Precip_OWM(i) = filas_grupo.Precip(j);
                end
            end
        end
        
        % 1.2.1.2. Fusionamos los datos de las diferentes fuentes
        T_fusion =[grupos, table(Temp_AEMET, Temp_OM, Temp_OWM, Viento_AEMET, Viento_OM, Viento_OWM, Precip_AEMET, Precip_OM, Precip_OWM)];
        

        % 1.2.1.3. Arreglamos los huecos
        
        % Nos quedamos solo con las predicciones que podemos comprobar (existe dato observado)

        T_final = innerjoin(T_fusion, T_real, 'Keys', 'FechaObj');
        
        % Usamos INTERPOLACIÓN LINEAL para los huecos de 3 horas de OWM
        
        % Ordenamos cronológicamente antes de interpolar
        T_final = sortrows(T_final, 'FechaObj');
        T_final.Temp_OWM = fillmissing(T_final.Temp_OWM, 'linear');
        T_final.Viento_OWM = fillmissing(T_final.Viento_OWM, 'linear');
        T_final.Precip_OWM = fillmissing(T_final.Precip_OWM, 'linear');
        
        % Si queda algún NaN en los extremos (donde no se puede interpolar), 
        % usamos el valor más cercano ('nearest')
        T_final.Temp_OWM = fillmissing(T_final.Temp_OWM, 'nearest');
        T_final.Viento_OWM = fillmissing(T_final.Viento_OWM, 'nearest');
        T_final.Precip_OWM = fillmissing(T_final.Precip_OWM, 'nearest');
        
        T_final = rmmissing(T_final);
    
end


%% 2. ENTRENAMIENTO (100% DATOS)
function mod_simple = entrenar_modelo_simple(T_final)
    
    % Siguiendo la fórmula del glm: coeficientes = pinv(A) * y

    % 1. Montamos la matriz A para cada modelo
    col_unos = ones(height(T_final), 1);
    Atemp     =[T_final.Temp_AEMET, T_final.Temp_OM, T_final.Temp_OWM, col_unos];
    Aviento   =[T_final.Viento_AEMET, T_final.Viento_OM, T_final.Viento_OWM, col_unos];
    Aprecip   =[T_final.Precip_AEMET, T_final.Precip_OM, T_final.Precip_OWM, col_unos];
    
    % 2. Aplicamos la fórmula y obtenemos los coeficientes para los 3 modelos
    mod_simple.temp   = pinv(Atemp) * T_final.Temp_REAL;
    mod_simple.viento = pinv(Aviento) * T_final.Viento_REAL;
    mod_simple.precip = pinv(Aprecip) * T_final.Precip_REAL;
end


function mod_complejo = entrenar_modelo_complejo(T_final)
    
    % Siguiendo la fórmula del glm: coeficientes = pinv(A) * y

    % 1. Montamos la matriz A para cada modelo 
    % (como usamos todas las características, es la misma para todas)
    col_unos = ones(height(T_final), 1);
    vars_complejo = {'Temp_AEMET', 'Temp_OM', 'Temp_OWM', ...
                     'Viento_AEMET', 'Viento_OM', 'Viento_OWM', ...
                     'Precip_AEMET', 'Precip_OM', 'Precip_OWM'};
    A = [T_final{:, vars_complejo}, col_unos];
    
    % 2. Aplicamos la fórmula y obtenemos los coeficientes para los 3 modelos
    mod_complejo.temp   = pinv(A) * T_final.Temp_REAL;
    mod_complejo.viento = pinv(A) * T_final.Viento_REAL;
    mod_complejo.precip = pinv(A) * T_final.Precip_REAL;
end

