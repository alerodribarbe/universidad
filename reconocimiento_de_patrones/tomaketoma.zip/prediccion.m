% =========================================================================
% SCRIPT: prediccion.m
% Fase 3: Inferencia y Generación del fichero miprediccion.txt
% =========================================================================
clear all; close all; clc;

disp('1. Cargando el modelo entrenado...');
load('modelo.mat'); % Carga coefs_temp, coefs_viento, coefs_precip
disp(['   [OK] Modelo cargado ']);



disp('2. Descargando predicciones actuales...');
T_pred = obtener_predicciones();
disp(['   [OK] Predicciones obtenidas ']);


disp('3. Comprobando que esten los datos correctos...');
T_pred = corregir_datos(T_pred);
disp(['   [OK] Se corrigieron ']);

% --- CONFIGURACIÓN ---




disp('4. Aplicando el modelo de Mezcla de Expertos (GLM Simple)...');
col_unos = ones(48, 1);

% Matrices X independientes para cada variable (3 APIs + término independiente)
X_test_temp   =[T_pred.Temp_AEMET, T_pred.Temp_OM, T_pred.Temp_OWM, col_unos];
X_test_viento =[T_pred.Viento_AEMET, T_pred.Viento_OM, T_pred.Viento_OWM, col_unos];
X_test_precip =[T_pred.Precip_AEMET, T_pred.Precip_OM, T_pred.Precip_OWM, col_unos];

% Predicciones finales
Pred_Temp   = X_test_temp * coefs_temp;
Pred_Viento = max(0, X_test_viento * coefs_viento);
Pred_Precip = max(0, X_test_precip * coefs_precip);

disp('5. Generando fichero miprediccion.txt...');
fid = fopen('miprediccion.txt', 'w');
fprintf(fid, '%s\n', datestr(now, 'dd-mm-yyyy hh:MM'));
fprintf(fid, '%.1f ', Pred_Temp); fprintf(fid, '\n');
fprintf(fid, '%.1f ', Pred_Viento); fprintf(fid, '\n');
fprintf(fid, '%.1f ', Pred_Precip); fprintf(fid, '\n');
fclose(fid);

disp('======================================================');
disp('[OK] Fichero miprediccion.txt generado correctamente.');
disp('======================================================');











function T_pred = obtener_predicciones()
    AEMET_API_KEY = 'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJqb3NlYWx2YXJvLmdhcmNpYW1hcnF1ZXpAYWx1bS51Y2EuZXMiLCJqdGkiOiI5ZTdmYWJmMS03Mzg0LTRmMjQtOGViNi0zYmVhMzdkMzcxZDMiLCJpc3MiOiJBRU1FVCIsImlhdCI6MTc3NDYxNDIxMSwidXNlcklkIjoiOWU3ZmFiZjEtNzM4NC00ZjI0LThlYjYtM2JlYTM3ZDM3MWQzIiwicm9sZSI6IiJ9.3GJpm1Gi0s-Hp_fewGEJekgSrbuczmNVVIM4jZw1ozM';
    OWM_API_KEY   = '3ed43db915aad74749f1a283b53c1c42';
    LAT = 36.4640; LON = -6.1983;
    MUNICIPIO_COD = '11031';
    
    ahora = datetime('now', 'TimeZone', 'UTC');
    hora_inicio = dateshift(ahora, 'start', 'hour') + hours(1);
    horas_objetivo = hora_inicio + hours(0:47)';
    
    
    T_pred = timetable(horas_objetivo, NaN(48,1), NaN(48,1), NaN(48,1), NaN(48,1), NaN(48,1), NaN(48,1), NaN(48,1), NaN(48,1), NaN(48,1), ...
        'VariableNames', {'Temp_AEMET', 'Temp_OM', 'Temp_OWM', 'Viento_AEMET', 'Viento_OM', 'Viento_OWM', 'Precip_AEMET', 'Precip_OM', 'Precip_OWM'});
    
    % --- OPEN-METEO ---
    try
        url_om = sprintf('https://api.open-meteo.com/v1/forecast?latitude=%.4f&longitude=%.4f&hourly=temperature_2m,precipitation,wind_speed_10m&wind_speed_unit=kmh&forecast_days=3&timezone=UTC', LAT, LON);
        data_om = webread(url_om, weboptions('Timeout', 20));
        for i = 1:length(data_om.hourly.time)
            t_om = datetime(data_om.hourly.time{i}, 'InputFormat', 'yyyy-MM-dd''T''HH:mm', 'TimeZone', 'UTC');
            idx = find(horas_objetivo == t_om);
            if ~isempty(idx)
                T_pred.Temp_OM(idx) = data_om.hourly.temperature_2m(i);
                T_pred.Viento_OM(idx) = data_om.hourly.wind_speed_10m(i);
                T_pred.Precip_OM(idx) = data_om.hourly.precipitation(i);
            end
        end
    catch ME, disp(['Aviso: Falló Open-Meteo. ', ME.message]); end
    
    % --- OPEN WEATHER MAP (OWM) ---
    try
        url_owm = sprintf('https://api.openweathermap.org/data/2.5/forecast?lat=%.4f&lon=%.4f&appid=%s&units=metric&cnt=16', LAT, LON, OWM_API_KEY);
        data_owm = webread(url_owm, weboptions('Timeout', 20));
        lista = data_owm.list;
        if iscell(lista), lista =[lista{:}]; end
        for i = 1:length(lista)
            t_owm = datetime(lista(i).dt, 'ConvertFrom', 'posixtime', 'TimeZone', 'UTC');
            idx = find(horas_objetivo == t_owm);
            if ~isempty(idx)
                T_pred.Temp_OWM(idx) = lista(i).main.temp;
                T_pred.Viento_OWM(idx) = lista(i).wind.speed * 3.6;
                if isfield(lista(i), 'rain') && isfield(lista(i).rain, 'x3h')
                    T_pred.Precip_OWM(idx) = lista(i).rain.x3h;
                else
                    T_pred.Precip_OWM(idx) = 0;
                end
            end
        end
    catch ME, disp(['Aviso: Falló OWM. ', ME.message]); end
    
    % --- AEMET ---
    try
        endpoint =['/prediccion/especifica/municipio/horaria/', MUNICIPIO_COD];
        data_aemet = aemet_fetch(endpoint, AEMET_API_KEY);
        if ~isempty(data_aemet)
            if iscell(data_aemet), data_aemet = data_aemet{1}; end
            dias = data_aemet.prediccion.dia;
            for d = 1:length(dias)
                if iscell(dias), dia = dias{d}; else, dia = dias(d); end
                fecha_str = dia.fecha(1:10);
                
                temps = extract_aemet_var(dia.temperatura);
                precips = extract_aemet_var(dia.precipitacion);
                
                vientos = containers.Map();
                if isfield(dia, 'vientoAndRachaMax')
                    v_array = dia.vientoAndRachaMax;
                    for v = 1:length(v_array)
                        if iscell(v_array), item = v_array{v}; else, item = v_array(v); end
                        if isfield(item, 'periodo') && ~isempty(item.periodo)
                            p = str2double(item.periodo);
                            if isfield(item, 'velocidad') && ~isempty(item.velocidad)
                                if iscell(item.velocidad), val_v = item.velocidad{1}; else, val_v = item.velocidad; end
                                vientos(num2str(p)) = str2double(val_v);
                            end
                        end
                    end
                end
                
                for h = 0:23
                    h_str = num2str(h);
                    t_aemet = datetime(sprintf('%sT%02d:00', fecha_str, h), 'InputFormat', 'yyyy-MM-dd''T''HH:mm', 'TimeZone', 'UTC');
                    t_aemet = t_aemet - hours(2); % % La aemet da los datos en utc+2
                    idx = find(horas_objetivo == t_aemet);
                    if ~isempty(idx)
                        if isKey(temps, h_str), T_pred.Temp_AEMET(idx) = str2double(temps(h_str)); end
                        if isKey(vientos, h_str), T_pred.Viento_AEMET(idx) = str2double(vientos(h_str)); end
                        if isKey(precips, h_str), T_pred.Precip_AEMET(idx) = str2double(precips(h_str)); end
                    end
                end
            end
        end
    catch ME, disp(['Aviso: Falló AEMET. ', ME.message]); end
    

end

function T_pred = corregir_datos(T_pred)
%{
Esta función actúa como un sistema de tolerancia a fallos y de imputación 
de datos incompletos. 
Su objetivo es garantizar que la matriz de entrada al modelo (X) no 
contenga ningún NaN, evitando así que el modelo matemático colapse.

Esta función solo funcionará si open meteo, no falla, ya que en la experiencia, 
nunca hemos obtenido una respuesta errónea de dicha api.


Estrategia aplicada:
    1. Sustitución Cruzada: Si AEMET u OWM tienen huecos puntuales, se 
    rellenan usando los datos de Open-Meteo de esa misma hora.
    2. Interpolación Temporal: Se aplica interpolación lineal para rellenar 
    los saltos de 3 horas de OWM, manteniendo la coherencia física de 
    la serie temporal.
%}

    % Comprobamos la temperatura como indicador de si la API ha fallado
    if all(isnan(T_pred.Temp_OM))
        disp('   [!] ALERTA CRÍTICA: Open-Meteo falló por completo. La predicción fallará .');
    end
    if any(isnan(T_pred.Temp_AEMET))
        disp('   [!] Aviso: Faltan datos en AEMET. Rellenando huecos con Open-Meteo.');
    end
    if any(isnan(T_pred.Temp_OWM))
        disp('   [!] Aviso: Faltan datos en OWM (o tiene saltos de 3h). Rellenando/Interpolando.');
    end

    % --- REPARACIÓN DE DATOS ---
    vars = {'Temp', 'Viento', 'Precip'};
    for v = 1:length(vars)
        var = vars{v};
        col_aemet = [var '_AEMET']; col_om = [var '_OM']; col_owm = [var '_OWM'];
        
        
        % Rellenar AEMET con OM si hay NaNs
        idx_nan_aemet = isnan(T_pred.(col_aemet)); 
        T_pred.(col_aemet)(idx_nan_aemet) = T_pred.(col_om)(idx_nan_aemet);
        
        % Rellenar OWM con OM si hay NaNs
        idx_nan_owm = isnan(T_pred.(col_owm)); 
        T_pred.(col_owm)(idx_nan_owm) = T_pred.(col_om)(idx_nan_owm);
    end
    
    % Interpolación final para suavizar las curvas
    T_pred = fillmissing(T_pred, 'linear');
    T_pred = fillmissing(T_pred, 'nearest');
end



% =========================================================================
% FUNCIONES AUXILIARES
% =========================================================================
function data = aemet_fetch(endpoint, api_key)
    base_url = 'https://opendata.aemet.es/opendata/api';
    options = weboptions('HeaderFields', {'api_key', api_key; 'Accept', 'application/json'}, 'Timeout', 20);
    data =[];
    try
        meta = webread([base_url, endpoint], options);
        if ischar(meta) || isstring(meta), meta = jsondecode(meta); end
        if meta.estado == 200
            raw_data = webread(meta.datos, weboptions('Timeout', 20));
            if ischar(raw_data) || isstring(raw_data), data = jsondecode(raw_data); else, data = raw_data; end
        end
    catch
    end
end

function map = extract_aemet_var(data_in)
    map = containers.Map();
    for i = 1:length(data_in)
        if iscell(data_in), item = data_in{i}; else, item = data_in(i); end
        if isfield(item, 'periodo') && ~isempty(item.periodo) && isfield(item, 'value') && ~isempty(item.value)
            map(num2str(str2double(item.periodo))) = item.value;
        end
    end
end