% =========================================================================
% SCRIPT: acumula_datos_diario.m (VERSIÓN - 3 VARIABLES)
% Práctica Global - Reconocimiento de Patrones
% Recolector de datos meteorológicos (AEMET, Open-Meteo, OWM)
% =========================================================================

function acumula_datos_diario()
    % --- CONFIGURACIÓN ---
    AEMET_API_KEY = 'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJqb3NlYWx2YXJvLmdhcmNpYW1hcnF1ZXpAYWx1bS51Y2EuZXMiLCJqdGkiOiI5ZTdmYWJmMS03Mzg0LTRmMjQtOGViNi0zYmVhMzdkMzcxZDMiLCJpc3MiOiJBRU1FVCIsImlhdCI6MTc3NDYxNDIxMSwidXNlcklkIjoiOWU3ZmFiZjEtNzM4NC00ZjI0LThlYjYtM2JlYTM3ZDM3MWQzIiwicm9sZSI6IiJ9.3GJpm1Gi0s-Hp_fewGEJekgSrbuczmNVVIM4jZw1ozM';
    OWM_API_KEY   = '3ed43db915aad74749f1a283b53c1c42';
    
    LAT = 36.4640;
    LON = -6.1983;
    AEMET_STATION = '5972X'; % San Fernando
    MUNICIPIO_COD = '11031'; % San Fernando
    
    HISTORICO_PATH = 'historico.txt';
    
    % Tiempo actual en UTC
    ts_cap_dt = datetime('now', 'TimeZone', 'UTC');
    ts_cap = datestr(ts_cap_dt, 'yyyy-mm-ddTHH:MM');
    
    disp(['=== Recolección iniciada: ', ts_cap, ' ===']);
    
    lineas = {};
    
    % 1. AEMET Predicción
    disp('Descargando AEMET Predicción...');
    res = collect_aemet_forecast(ts_cap, MUNICIPIO_COD, AEMET_API_KEY);
    lineas =[lineas(:); res(:)];
    
    % 2. AEMET Observación (REAL)
    disp('Descargando AEMET Observación (REAL)...');
    res = collect_aemet_observation(ts_cap, AEMET_STATION, AEMET_API_KEY);
    lineas = [lineas(:); res(:)];
    
    % 3. Open-Meteo Predicción
    disp('Descargando Open-Meteo Predicción...');
    res = collect_openmeteo_forecast(ts_cap, LAT, LON, ts_cap_dt);
    lineas = [lineas(:); res(:)];
    
    % 4. OpenWeatherMap (OWM) Predicción
    disp('Descargando OWM Predicción...');
    res = collect_owm_forecast(ts_cap, LAT, LON, OWM_API_KEY);
    lineas =[lineas(:); res(:)];
    
    % Guardar en fichero
    if ~isempty(lineas)
        fid = fopen(HISTORICO_PATH, 'a');
        for i = 1:length(lineas)
            fprintf(fid, '%s\n', lineas{i});
        end
        fclose(fid);
        disp(['=== Recolección completada: Escritas ', num2str(length(lineas)), ' líneas ===']);
    else
        disp('=== Recolección fallida: No se obtuvieron datos ===');
    end
end

% =========================================================================
% FUNCIONES DE RECOLECCIÓN
% =========================================================================

function lineas = collect_aemet_forecast(ts_cap, municipio, api_key)
    lineas = {};
    endpoint =['/prediccion/especifica/municipio/horaria/', municipio];
    data = aemet_fetch(endpoint, api_key);
    
    if isempty(data)
        return;
    end
    
    try
        if iscell(data), data = data{1}; end
        
        dias = data.prediccion.dia;
        for d = 1:length(dias)
            if iscell(dias), dia = dias{d}; else, dia = dias(d); end
            fecha = dia.fecha(1:10);
            
            temps = extract_aemet_var(dia.temperatura);
            precips = extract_aemet_var(dia.precipitacion);
            
            vientos = containers.Map();
            if isfield(dia, 'vientoAndRachaMax')
                v_array = dia.vientoAndRachaMax;
                for v = 1:length(v_array)
                    if iscell(v_array), item = v_array{v}; else, item = v_array(v); end
                    if isfield(item, 'periodo') && ~isempty(item.periodo)
                        p = str2double(item.periodo);
                        if isfield(item, 'velocidad') && ~isempty(item.velocidad)
                            if iscell(item.velocidad), val_v = item.velocidad{1}; else, val_v = item.velocidad; end
                            vientos(num2str(p)) = str2double(val_v);
                        end
                    end
                end
            end
            
            for h = 0:23
                h_str = num2str(h);
                if isKey(temps, h_str) || isKey(vientos, h_str) || isKey(precips, h_str)
                    ts_pred = sprintf('%sT%02d:00', fecha, h);
                    linea = sprintf('PRED;AEMET;%s;%s;%s;%s;%s', ...
                        ts_cap, ts_pred, ...
                        get_val(temps, h_str), get_val(vientos, h_str), get_val(precips, h_str));
                    lineas{end+1} = linea;
                end
            end
        end
    catch ME
        disp(['Error procesando AEMET PRED: ', ME.message]);
    end
end

function lineas = collect_aemet_observation(ts_cap, estacion, api_key)
    lineas = {};
    endpoint =['/observacion/convencional/datos/estacion/', estacion];
    data = aemet_fetch(endpoint, api_key);
    
    if isempty(data)
        return;
    end
    
    try
        if iscell(data)
            fints = cellfun(@(x) x.fint, data, 'UniformOutput', false);[~, idx] = sort(string(fints), 'descend');
            obs = data{idx(1)};
        else
            fints = {data.fint};
            [~, idx] = sort(string(fints), 'descend');
            obs = data(idx(1));
        end
        
        ts_obs = strrep(obs.fint(1:16), ' ', 'T');
        
        temp = get_field_num(obs, 'ta');
        viento = ms_to_kmh(get_field_num(obs, 'vv'));
        precip = get_field_num(obs, 'prec');
        
        linea = sprintf('REAL;AEMET;%s;%s;%s;%s', ...
            ts_obs, fv(temp), fv(viento), fv(precip));
        lineas{end+1} = linea;
    catch ME
        disp(['Error procesando AEMET OBS: ', ME.message]);
    end
end

function lineas = collect_openmeteo_forecast(ts_cap, lat, lon, ts_cap_dt)
    lineas = {};
    % Solo pedimos temperatura, viento y precipitación
    url = sprintf('https://api.open-meteo.com/v1/forecast?latitude=%.4f&longitude=%.4f&hourly=temperature_2m,precipitation,wind_speed_10m&wind_speed_unit=kmh&forecast_days=3&timezone=UTC', lat, lon);
    
    try
        options = weboptions('Timeout', 20);
        data = webread(url, options);
        
        times = data.hourly.time;
        now_trunc = dateshift(ts_cap_dt, 'start', 'hour');
        
        for i = 1:length(times)
            ts_pred_dt = datetime(times{i}, 'InputFormat', 'yyyy-MM-dd''T''HH:mm', 'TimeZone', 'UTC');
            if ts_pred_dt < now_trunc
                continue;
            end
            if hours(ts_pred_dt - now_trunc) > 48
                break;
            end
            
            linea = sprintf('PRED;OPEN-METEO;%s;%s;%s;%s;%s', ...
                ts_cap, times{i}, ...
                fv(data.hourly.temperature_2m(i)), fv(data.hourly.wind_speed_10m(i)), ...
                fv(data.hourly.precipitation(i)));
            lineas{end+1} = linea;
        end
    catch ME
        disp(['Error procesando Open-Meteo: ', ME.message]);
    end
end

function lineas = collect_owm_forecast(ts_cap, lat, lon, api_key)
    lineas = {};
    url = sprintf('https://api.openweathermap.org/data/2.5/forecast?lat=%.4f&lon=%.4f&appid=%s&units=metric&cnt=16', lat, lon, api_key);
    
    try
        options = weboptions('Timeout', 20);
        data = webread(url, options);
        
        lista = data.list;
        for i = 1:length(lista)
            if iscell(lista), item = lista{i}; else, item = lista(i); end
            
            ts_pred_dt = datetime(item.dt, 'ConvertFrom', 'posixtime', 'TimeZone', 'UTC');
            ts_pred = datestr(ts_pred_dt, 'yyyy-mm-ddTHH:MM');
            
            temp = item.main.temp;
            viento = ms_to_kmh(item.wind.speed);
            
            precip = 0;
            if isfield(item, 'rain') && isfield(item.rain, 'x3h')
                precip = item.rain.x3h;
            end
            
            linea = sprintf('PRED;OWM;%s;%s;%s;%s;%s', ...
                ts_cap, ts_pred, fv(temp), fv(viento), fv(precip));
            lineas{end+1} = linea;
        end
    catch ME
        disp(['Error procesando OWM: ', ME.message]);
    end
end

% =========================================================================
% FUNCIONES AUXILIARES
% =========================================================================

function data = aemet_fetch(endpoint, api_key)
    base_url = 'https://opendata.aemet.es/opendata/api';
    options = weboptions('HeaderFields', {'api_key', api_key; 'Accept', 'application/json'}, 'Timeout', 20);
    data =[];
    try
        meta = webread([base_url, endpoint], options);
        if ischar(meta) || isstring(meta), meta = jsondecode(meta); end
        
        if meta.estado == 200
            raw_data = webread(meta.datos, weboptions('Timeout', 20));
            if ischar(raw_data) || isstring(raw_data)
                data = jsondecode(raw_data);
            else
                data = raw_data;
            end
        else
            disp(['AEMET Warning: ', meta.descripcion]);
        end
    catch ME
        disp(['Fallo de conexión con AEMET: ', endpoint, ' - ', ME.message]);
    end
end

function map = extract_aemet_var(data_in)
    map = containers.Map();
    for i = 1:length(data_in)
        if iscell(data_in), item = data_in{i}; else, item = data_in(i); end
        if isfield(item, 'periodo') && ~isempty(item.periodo) && isfield(item, 'value') && ~isempty(item.value)
            map(num2str(str2double(item.periodo))) = str2double(item.value);
        end
    end
end

function val = get_val(map, key)
    if isKey(map, key)
        val = fv(map(key));
    else
        val = 'nan';
    end
end

function val = get_field_num(st, field)
    val = NaN;
    if isfield(st, field) && ~isempty(st.(field))
        val = st.(field);
    end
end

function s = fv(v)
    if isempty(v) || isnan(v)
        s = 'nan';
    else
        s = sprintf('%.1f', v);
    end
end

function kmh = ms_to_kmh(ms)
    if isnan(ms)
        kmh = NaN;
    else
        kmh = ms * 3.6;
    end
end