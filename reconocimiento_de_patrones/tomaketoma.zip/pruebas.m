% =========================================================================
% SCRIPT: entrenamiento.m
% Pipeline de Machine Learning: Preprocesado, Validación, Entrenamiento y Gráficas
% =========================================================================
clearvars; close all; clc;

disp('=== INICIANDO PIPELINE DE MACHINE LEARNING ===');

% 1. FASE DE PREPROCESADO
disp('-> [Fase 1] Preprocesando y fusionando datos...');
T_final = preprocesar_datos('historico.txt');
disp(['   [OK] Filas de entrenamiento disponibles: ', num2str(height(T_final))]);


% 2. FASE DE VALIDACIÓN (10-Fold Cross-Validation)
disp('-> [Fase 2] Validando modelos (10-Fold Cross-Validation)...');
rmse_cv = validar_modelos_cv(T_final);
disp('   [OK] Validación cruzada completada.');

% 3. FASE DE ENTRENAMIENTO FINAL (100% de los datos)
disp('-> [Fase 3] Entrenando modelo FINAL (100% datos) para guardar en modelo.mat...');
[mod_simple, mod_complejo] = entrenar_modelo_final(T_final);

% Guardar el modelo simple para prediccion.m
coefs_temp = mod_simple.temp;
coefs_viento = mod_simple.viento;
coefs_precip = mod_simple.precip;
save('modelo.mat', 'coefs_temp', 'coefs_viento', 'coefs_precip');

disp('   [OK] Modelo guardado en modelo.mat');


% 4. FASE DE VISUALIZACIÓN (Interfaz Gráfica y Backtesting)
disp('-> [Fase 4] Generando Interfaz Gráfica...');
plotear_resultados(T_final, mod_simple, mod_complejo, rmse_cv);
disp('   [OK] Interfaz gráfica generada.');

disp('=== PIPELINE COMPLETADO CON ÉXITO ===');


% =========================================================================
% FUNCIONES LOCALES
% =========================================================================

%% 1. PREPROCESADO Y FUSIÓN DE DATOS
function T_final = preprocesar_datos(fichero)
    
% 1.1.Cargamos el histórico
    fid = fopen(fichero, 'r');
    lineas = textscan(fid, '%s', 'Delimiter', '\n');
    fclose(fid);
    lineas = lineas{1};

    datos_real = {}; datos_pred = {};

    for i = 1:length(lineas)
        elementos = strsplit(lineas{i}, ';');
        tipo = elementos{1};

        if strcmp(tipo, 'PRED') % Datos de prediccion
            fuente = elementos{2};
            f_cap = datetime(elementos{3}, 'InputFormat', 'yyyy-MM-dd''T''HH:mm');
            
            f_obj = datetime(elementos{4}, 'InputFormat', 'yyyy-MM-dd''T''HH:mm');
            if strcmp(fuente, 'AEMET'); f_obj = f_obj - hours(2); end   % La aemet da los datos en utc+2
            
            temp = str2double(elementos{5});
            viento = str2double(elementos{6});
            precip = str2double(elementos{7});

            horizonte = round(hours(f_obj - f_cap));

            if horizonte > 0 && horizonte <= 48
                datos_pred(end+1, :) = {fuente, f_obj, horizonte, temp, viento, precip};
            end

        elseif strcmp(tipo, 'REAL') % Datos de observacion
            f_obs = datetime(elementos{3}, 'InputFormat', 'yyyy-MM-dd''T''HH:mm');
            temp = str2double(elementos{4});
            viento = str2double(elementos{5});
            precip = str2double(elementos{6});

            datos_real(end+1, :) = {f_obs, temp, viento, precip};
        end
    end

% 1.2. Limpiamos los datos

    % 1.2.1. Obtenemos los Datos de observacion (la Y)
    T_real = cell2table(datos_real, 'VariableNames', {'FechaObj', 'Temp_REAL', 'Viento_REAL', 'Precip_REAL'});
    [~, idx_unique] = unique(T_real.FechaObj); % Eliminamos fechas repetidas
    T_real = T_real(idx_unique, :);

    % 1.2.1. Obtenemos los Datos de prediccion (patrones)
    T_pred = cell2table(datos_pred, 'VariableNames', {'Fuente', 'FechaObj', 'Horizonte', 'Temp', 'Viento', 'Precip'});

        % 1.2.1.1. Obtenemos los datos aislados de cada fuente
        [grupos, ~, idx_grupos] = unique(T_pred(:, {'FechaObj', 'Horizonte'}), 'rows');
    
        N = height(grupos);
        Temp_AEMET = NaN(N,1); Temp_OM = NaN(N,1); Temp_OWM = NaN(N,1);
        Viento_AEMET = NaN(N,1); Viento_OM = NaN(N,1); Viento_OWM = NaN(N,1);
        Precip_AEMET = NaN(N,1); Precip_OM = NaN(N,1); Precip_OWM = NaN(N,1);
    
        for i = 1:N
            filas_grupo = T_pred(idx_grupos == i, :);
            for j = 1:height(filas_grupo)
                fuente = filas_grupo.Fuente{j};
                if strcmp(fuente, 'AEMET')
                    Temp_AEMET(i) = filas_grupo.Temp(j); Viento_AEMET(i) = filas_grupo.Viento(j); Precip_AEMET(i) = filas_grupo.Precip(j);
                elseif strcmp(fuente, 'OPEN-METEO')
                    Temp_OM(i) = filas_grupo.Temp(j); Viento_OM(i) = filas_grupo.Viento(j); Precip_OM(i) = filas_grupo.Precip(j);
                elseif strcmp(fuente, 'OWM')
                    Temp_OWM(i) = filas_grupo.Temp(j); Viento_OWM(i) = filas_grupo.Viento(j); Precip_OWM(i) = filas_grupo.Precip(j);
                end
            end
        end
        
        % 1.2.1.2. Fusionamos los datos de las diferentes fuentes
        T_fusion =[grupos, table(Temp_AEMET, Temp_OM, Temp_OWM, Viento_AEMET, Viento_OM, Viento_OWM, Precip_AEMET, Precip_OM, Precip_OWM)];
        

        % 1.2.1.3. Arreglamos los huecos
        
        % Nos quedamos solo con las predicciones que podemos comprobar (existe dato observado)

        T_final = innerjoin(T_fusion, T_real, 'Keys', 'FechaObj');
        
        % Usamos INTERPOLACIÓN LINEAL para los huecos de 3 horas de OWM
        
        % Ordenamos cronológicamente antes de interpolar
        T_final = sortrows(T_final, 'FechaObj');
        T_final.Temp_OWM = fillmissing(T_final.Temp_OWM, 'linear');
        T_final.Viento_OWM = fillmissing(T_final.Viento_OWM, 'linear');
        T_final.Precip_OWM = fillmissing(T_final.Precip_OWM, 'linear');
        
        % Si queda algún NaN en los extremos (donde no se puede interpolar), 
        % usamos el valor más cercano ('nearest')
        T_final.Temp_OWM = fillmissing(T_final.Temp_OWM, 'nearest');
        T_final.Viento_OWM = fillmissing(T_final.Viento_OWM, 'nearest');
        T_final.Precip_OWM = fillmissing(T_final.Precip_OWM, 'nearest');
        
        T_final = rmmissing(T_final);
    
end

%% 2. VALIDACIÓN CRUZADA (10-Fold CV)
function rmse_cv = validar_modelos_cv(T_final)
    
    rng('default'); 
    idx_rand = randperm(height(T_final));
    T_final = T_final(idx_rand, :);

    K = 10;
    cv = cvpartition(height(T_final), 'KFold', K);

    sq_errors_temp = zeros(4, 5); sq_errors_viento = zeros(4, 5); sq_errors_precip = zeros(4, 5);
    counts_tramos = zeros(4, 1);
    tramos =[1 12; 13 24; 25 36; 37 48];
    
    vars_complejo = {'Temp_AEMET', 'Temp_OM', 'Temp_OWM', ...
                     'Viento_AEMET', 'Viento_OM', 'Viento_OWM', ...
                     'Precip_AEMET', 'Precip_OM', 'Precip_OWM'};

    for k = 1:K
        T_train = T_final(training(cv, k), :);
        T_test  = T_final(test(cv, k), :);

        col_unos_train = ones(height(T_train), 1);

        % Entrenar en Train
        X_train_comp     =[T_train{:, vars_complejo}, col_unos_train];
        X_train_temp_s   =[T_train.Temp_AEMET, T_train.Temp_OM, T_train.Temp_OWM, col_unos_train];
        X_train_viento_s =[T_train.Viento_AEMET, T_train.Viento_OM, T_train.Viento_OWM, col_unos_train];
        X_train_precip_s =[T_train.Precip_AEMET, T_train.Precip_OM, T_train.Precip_OWM, col_unos_train];

        w_temp_c   = pinv(X_train_comp) * T_train.Temp_REAL;
        w_viento_c = pinv(X_train_comp) * T_train.Viento_REAL;
        w_precip_c = pinv(X_train_comp) * T_train.Precip_REAL;

        w_temp_s   = pinv(X_train_temp_s) * T_train.Temp_REAL;
        w_viento_s = pinv(X_train_viento_s) * T_train.Viento_REAL;
        w_precip_s = pinv(X_train_precip_s) * T_train.Precip_REAL;

        % Evaluar en Test
        for i = 1:4
            idx_tramo = T_test.Horizonte >= tramos(i,1) & T_test.Horizonte <= tramos(i,2);
            T_tramo = T_test(idx_tramo, :);

            if height(T_tramo) > 0
                col_unos_test = ones(height(T_tramo), 1);

                X_test_comp      =[T_tramo{:, vars_complejo}, col_unos_test];
                X_test_temp_s    =[T_tramo.Temp_AEMET, T_tramo.Temp_OM, T_tramo.Temp_OWM, col_unos_test];
                X_test_viento_s  =[T_tramo.Viento_AEMET, T_tramo.Viento_OM, T_tramo.Viento_OWM, col_unos_test];
                X_test_precip_s  =[T_tramo.Precip_AEMET, T_tramo.Precip_OM, T_tramo.Precip_OWM, col_unos_test];

                P_Temp_c = X_test_comp * w_temp_c;
                P_Viento_c = max(0, X_test_comp * w_viento_c);
                P_Precip_c = max(0, X_test_comp * w_precip_c);

                P_Temp_s = X_test_temp_s * w_temp_s;
                P_Viento_s = max(0, X_test_viento_s * w_viento_s);
                P_Precip_s = max(0, X_test_precip_s * w_precip_s);

                % Acumular errores
                sq_errors_temp(i, 1) = sq_errors_temp(i, 1) + sum((T_tramo.Temp_REAL - P_Temp_c).^2);
                sq_errors_temp(i, 2) = sq_errors_temp(i, 2) + sum((T_tramo.Temp_REAL - P_Temp_s).^2);
                sq_errors_temp(i, 3) = sq_errors_temp(i, 3) + sum((T_tramo.Temp_REAL - T_tramo.Temp_AEMET).^2);
                sq_errors_temp(i, 4) = sq_errors_temp(i, 4) + sum((T_tramo.Temp_REAL - T_tramo.Temp_OM).^2);
                sq_errors_temp(i, 5) = sq_errors_temp(i, 5) + sum((T_tramo.Temp_REAL - T_tramo.Temp_OWM).^2);

                sq_errors_viento(i, 1) = sq_errors_viento(i, 1) + sum((T_tramo.Viento_REAL - P_Viento_c).^2);
                sq_errors_viento(i, 2) = sq_errors_viento(i, 2) + sum((T_tramo.Viento_REAL - P_Viento_s).^2);
                sq_errors_viento(i, 3) = sq_errors_viento(i, 3) + sum((T_tramo.Viento_REAL - T_tramo.Viento_AEMET).^2);
                sq_errors_viento(i, 4) = sq_errors_viento(i, 4) + sum((T_tramo.Viento_REAL - T_tramo.Viento_OM).^2);
                sq_errors_viento(i, 5) = sq_errors_viento(i, 5) + sum((T_tramo.Viento_REAL - T_tramo.Viento_OWM).^2);

                sq_errors_precip(i, 1) = sq_errors_precip(i, 1) + sum((T_tramo.Precip_REAL - P_Precip_c).^2);
                sq_errors_precip(i, 2) = sq_errors_precip(i, 2) + sum((T_tramo.Precip_REAL - P_Precip_s).^2);
                sq_errors_precip(i, 3) = sq_errors_precip(i, 3) + sum((T_tramo.Precip_REAL - T_tramo.Precip_AEMET).^2);
                sq_errors_precip(i, 4) = sq_errors_precip(i, 4) + sum((T_tramo.Precip_REAL - T_tramo.Precip_OM).^2);
                sq_errors_precip(i, 5) = sq_errors_precip(i, 5) + sum((T_tramo.Precip_REAL - T_tramo.Precip_OWM).^2);

                counts_tramos(i) = counts_tramos(i) + height(T_tramo);
            end
        end
    end

    rmse_cv.temp = sqrt(sq_errors_temp ./ counts_tramos);
    rmse_cv.viento = sqrt(sq_errors_viento ./ counts_tramos);
    rmse_cv.precip = sqrt(sq_errors_precip ./ counts_tramos);
end

%% 3. ENTRENAMIENTO FINAL (100% DATOS)
function [mod_simple, mod_complejo] = entrenar_modelo_final(T_final)
    
    col_unos_all = ones(height(T_final), 1);
    vars_complejo = {'Temp_AEMET', 'Temp_OM', 'Temp_OWM', ...
                     'Viento_AEMET', 'Viento_OM', 'Viento_OWM', ...
                     'Precip_AEMET', 'Precip_OM', 'Precip_OWM'};

    X_all_comp       =[T_final{:, vars_complejo}, col_unos_all];
    X_all_temp_s     =[T_final.Temp_AEMET, T_final.Temp_OM, T_final.Temp_OWM, col_unos_all];
    X_all_viento_s   =[T_final.Viento_AEMET, T_final.Viento_OM, T_final.Viento_OWM, col_unos_all];
    X_all_precip_s   =[T_final.Precip_AEMET, T_final.Precip_OM, T_final.Precip_OWM, col_unos_all];

    mod_complejo.temp   = pinv(X_all_comp) * T_final.Temp_REAL;
    mod_complejo.viento = pinv(X_all_comp) * T_final.Viento_REAL;
    mod_complejo.precip = pinv(X_all_comp) * T_final.Precip_REAL;

    mod_simple.temp   = pinv(X_all_temp_s) * T_final.Temp_REAL;
    mod_simple.viento = pinv(X_all_viento_s) * T_final.Viento_REAL;
    mod_simple.precip = pinv(X_all_precip_s) * T_final.Precip_REAL;
end

%% 4. VISUALIZACIÓN DE RESULTADOS
function plotear_resultados(T_final, mod_simple, mod_complejo, rmse_cv)
    
    nombres_tramos = {'[1h-12h]', '[13h-24h]', '[25h-36h]', '[37h-48h]'};
    leyenda_rmse = {'Mod. Complejo', 'Mod. Simple', 'AEMET', 'Open-Meteo', 'OWM'};
    leyenda_rmse_linea =[leyenda_rmse, {'Degradación Mod. Simple'}];

    f = figure('Name', 'Análisis de Modelos Meteorológicos', 'Position',[100, 100, 1000, 600], 'Color', 'w');
    tg = uitabgroup(f);

    % --- PESTAÑAS RMSE ---
    t1 = uitab(tg, 'Title', 'RMSE Temp'); ax1 = axes('Parent', t1);
    b1 = bar(ax1, rmse_cv.temp); 
    set(ax1, 'XTickLabel', nombres_tramos, 'Color', 'w', 'XColor', 'k', 'YColor', 'k', 'GridColor', 'k');
    hold(ax1, 'on');
    plot(ax1, b1(2).XEndPoints, rmse_cv.temp(:, 2), '-o', 'Color', b1(2).FaceColor, 'LineWidth', 2.5, 'MarkerSize', 8, 'MarkerFaceColor', 'w');
    legend(ax1, leyenda_rmse_linea, 'Location', 'northwest'); 
    title(ax1, 'Error RMSE en Temperatura (ºC)'); grid(ax1, 'on');

    t2 = uitab(tg, 'Title', 'RMSE Viento'); ax2 = axes('Parent', t2);
    b2 = bar(ax2, rmse_cv.viento); 
    set(ax2, 'XTickLabel', nombres_tramos, 'Color', 'w', 'XColor', 'k', 'YColor', 'k', 'GridColor', 'k');
    hold(ax2, 'on');
    plot(ax2, b2(2).XEndPoints, rmse_cv.viento(:, 2), '-o', 'Color', b2(2).FaceColor, 'LineWidth', 2.5, 'MarkerSize', 8, 'MarkerFaceColor', 'w');
    legend(ax2, leyenda_rmse_linea, 'Location', 'northwest'); 
    title(ax2, 'Error RMSE en Viento (km/h)'); grid(ax2, 'on');

    t3 = uitab(tg, 'Title', 'RMSE Precip'); ax3 = axes('Parent', t3);
    b3 = bar(ax3, rmse_cv.precip); 
    set(ax3, 'XTickLabel', nombres_tramos, 'Color', 'w', 'XColor', 'k', 'YColor', 'k', 'GridColor', 'k');
    hold(ax3, 'on');
    plot(ax3, b3(2).XEndPoints, rmse_cv.precip(:, 2), '-o', 'Color', b3(2).FaceColor, 'LineWidth', 2.5, 'MarkerSize', 8, 'MarkerFaceColor', 'w');
    legend(ax3, leyenda_rmse_linea, 'Location', 'northwest'); 
    title(ax3, 'Error RMSE en Precipitación (mm)'); grid(ax3, 'on');

    % --- PREPARAR DATOS BACKTESTING ---
    T_final = sortrows(T_final, 'FechaObj'); 
    fecha_max = max(T_final.FechaObj);
    fecha_min = fecha_max - hours(48);
    T_plot_raw = T_final(T_final.FechaObj >= fecha_min, :);

    vars_complejo = {'Temp_AEMET', 'Temp_OM', 'Temp_OWM', ...
                     'Viento_AEMET', 'Viento_OM', 'Viento_OWM', ...
                     'Precip_AEMET', 'Precip_OM', 'Precip_OWM'};

    X_plot_comp      =[T_plot_raw{:, vars_complejo}, ones(height(T_plot_raw), 1)];
    X_plot_temp_s    =[T_plot_raw.Temp_AEMET, T_plot_raw.Temp_OM, T_plot_raw.Temp_OWM, ones(height(T_plot_raw), 1)];
    X_plot_viento_s  =[T_plot_raw.Viento_AEMET, T_plot_raw.Viento_OM, T_plot_raw.Viento_OWM, ones(height(T_plot_raw), 1)];
    X_plot_precip_s  =[T_plot_raw.Precip_AEMET, T_plot_raw.Precip_OM, T_plot_raw.Precip_OWM, ones(height(T_plot_raw), 1)];

    T_plot_raw.P_Temp_c = X_plot_comp * mod_complejo.temp;
    T_plot_raw.P_Temp_s = X_plot_temp_s * mod_simple.temp;

    T_plot_raw.P_Viento_c = max(0, X_plot_comp * mod_complejo.viento);
    T_plot_raw.P_Viento_s = max(0, X_plot_viento_s * mod_simple.viento);

    T_plot_raw.P_Precip_c = max(0, X_plot_comp * mod_complejo.precip);
    T_plot_raw.P_Precip_s = max(0, X_plot_precip_s * mod_simple.precip);

    TT_plot = retime(table2timetable(T_plot_raw, 'RowTimes', 'FechaObj'), 'hourly', 'mean');

    leyenda_back = {'REAL', 'Mod. Complejo', 'Mod. Simple', 'AEMET', 'Open-Meteo'};

    % --- PESTAÑAS BACKTESTING ---
    t4 = uitab(tg, 'Title', 'Backtest Temp'); ax4 = axes('Parent', t4);
    plot(ax4, TT_plot.FechaObj, TT_plot.Temp_REAL, 'k-o', 'LineWidth', 2, 'MarkerFaceColor', 'k'); hold(ax4, 'on');
    plot(ax4, TT_plot.FechaObj, TT_plot.P_Temp_c, 'm-*', 'LineWidth', 1.5);
    plot(ax4, TT_plot.FechaObj, TT_plot.P_Temp_s, 'b-*', 'LineWidth', 2);
    plot(ax4, TT_plot.FechaObj, TT_plot.Temp_AEMET, 'r--', 'LineWidth', 1);
    plot(ax4, TT_plot.FechaObj, TT_plot.Temp_OM, 'g--', 'LineWidth', 1);
    set(ax4, 'Color', 'w', 'XColor', 'k', 'YColor', 'k', 'GridColor', 'k');
    legend(ax4, leyenda_back, 'Location', 'best'); title(ax4, 'Backtesting: Temperatura'); grid(ax4, 'on');

    t5 = uitab(tg, 'Title', 'Backtest Viento'); ax5 = axes('Parent', t5);
    plot(ax5, TT_plot.FechaObj, TT_plot.Viento_REAL, 'k-o', 'LineWidth', 2, 'MarkerFaceColor', 'k'); hold(ax5, 'on');
    plot(ax5, TT_plot.FechaObj, TT_plot.P_Viento_c, 'm-*', 'LineWidth', 1.5);
    plot(ax5, TT_plot.FechaObj, TT_plot.P_Viento_s, 'b-*', 'LineWidth', 2);
    plot(ax5, TT_plot.FechaObj, TT_plot.Viento_AEMET, 'r--', 'LineWidth', 1);
    plot(ax5, TT_plot.FechaObj, TT_plot.Viento_OM, 'g--', 'LineWidth', 1);
    set(ax5, 'Color', 'w', 'XColor', 'k', 'YColor', 'k', 'GridColor', 'k');
    legend(ax5, leyenda_back, 'Location', 'best'); title(ax5, 'Backtesting: Viento'); grid(ax5, 'on');

    t6 = uitab(tg, 'Title', 'Backtest Precip'); ax6 = axes('Parent', t6);
    plot(ax6, TT_plot.FechaObj, TT_plot.Precip_REAL, 'k-o', 'LineWidth', 2, 'MarkerFaceColor', 'k'); hold(ax6, 'on');
    plot(ax6, TT_plot.FechaObj, TT_plot.P_Precip_c, 'm-*', 'LineWidth', 1.5);
    plot(ax6, TT_plot.FechaObj, TT_plot.P_Precip_s, 'b-*', 'LineWidth', 2);
    plot(ax6, TT_plot.FechaObj, TT_plot.Precip_AEMET, 'r--', 'LineWidth', 1);
    plot(ax6, TT_plot.FechaObj, TT_plot.Precip_OM, 'g--', 'LineWidth', 1);
    set(ax6, 'Color', 'w', 'XColor', 'k', 'YColor', 'k', 'GridColor', 'k');
    legend(ax6, leyenda_back, 'Location', 'best'); title(ax6, 'Backtesting: Precipitación'); grid(ax6, 'on');

end
